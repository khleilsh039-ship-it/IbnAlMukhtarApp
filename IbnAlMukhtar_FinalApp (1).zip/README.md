# Ibn Al Mukhtar Android WebView App

Open this project in Android Studio and build.
