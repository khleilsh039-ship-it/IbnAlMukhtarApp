package com.ibnalmukhtar.store
import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        webView = findViewById(R.id.webview)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean { return false }
        }
        webView.webChromeClient = WebChromeClient()
        try {
            val cfg = assets.open("config.json").bufferedReader().use { it.readText() }
            val start = org.json.JSONObject(cfg).optString("START_URL", "https://khlilsh2017-creator.github.io/Ibn_al_mukhtar/")
            webView.loadUrl(start)
        } catch (e: Exception) {
            webView.loadUrl("https://khlilsh2017-creator.github.io/Ibn_al_mukhtar/")
        }
    }
    override fun onBackPressed() {
        if (this::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
